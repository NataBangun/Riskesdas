====================================================================
              Common requirements
====================================================================
Java 1.5 and higher must be installed. Check the version using:
> java -version


====================================================================
                 For Windows
====================================================================
Launch startkbd.cmd to start
> startkbd.cmd
Launch stopkbd.cmd to stop
> stopkbd.cmd


====================================================================
                 For Linux
====================================================================
Make sure that *.sh files have execution 
> permissions (> chmod +x *.sh)
   
Launch startkbd.sh to start
> startkbd.sh
Launch stopkbd.sh to stop
> stopkbd.sh

#!/bin/sh

java -cp bin:remote-kbd-server.jar plasma.remote.Main $*

#!/bin/sh

dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $dir
echo working directory is $dir
kbdcmd="java -cp bin:remote-kbd-server.jar plasma.remote.Main"

if [ -f .pid ]
  then
    export PID=`cat .pid`
    if [ "$(ps -p $PID | wc -l)" -gt 1 ]
    then    
       echo process $PID is already running
       
    else
       rm .pid
    fi
fi
  
if [ -f .pid ]
  then
    echo 
  else
    nohup $kbdcmd 1>.out 2>&1 &
    echo $!
    echo $! > .pid
fi
  
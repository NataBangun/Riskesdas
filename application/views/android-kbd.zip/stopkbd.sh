#!/bin/sh

dir=$(cd -P -- "$(dirname -- "$0")" && pwd -P)
cd $dir
kbdcmd="java -cp bin:remote-kbd-server.jar plasma.remote.Main"

if [ "$1" = "kill" ]
  then
     echo "try to kill process"
     if [ -f .pid ]
        then
            export PID=`cat .pid`
            echo killing $PID
    
            if [ "$(ps -p $PID | wc -l)" -gt 1 ]
               then    
                   kill -9 $PID
                   rm .pid
               else
                   echo "process $PID is not running"
            fi
        else
            echo "no PID found"
     fi
  else
      $kbdcmd stop
fi


